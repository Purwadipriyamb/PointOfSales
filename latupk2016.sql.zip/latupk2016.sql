-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Waktu pembuatan: 29. Januari 2016 jam 23:11
-- Versi Server: 5.1.36
-- Versi PHP: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `latupk2016`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `login`
--

CREATE TABLE IF NOT EXISTS `login` (
  `user` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  `status` varchar(45) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `login`
--

INSERT INTO `login` (`user`, `password`, `status`) VALUES
('member', 'member', 'member'),
('admin', 'admin', 'admin');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_tiket`
--

CREATE TABLE IF NOT EXISTS `tb_tiket` (
  `kode` varchar(45) NOT NULL,
  `jurusan` text NOT NULL,
  `harga` varchar(12) NOT NULL,
  PRIMARY KEY (`kode`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_tiket`
--

INSERT INTO `tb_tiket` (`kode`, `jurusan`, `harga`) VALUES
('1', 'Tangerang', '350.000'),
('40', 'Semarang', '150.000'),
('36', 'Salatiga', '200.000'),
('32', 'Semarang', '250.000'),
('31', 'Tangerang', '100.000'),
('30', 'Salatiga', '200.000'),
('29', 'Tangerang', '250.000'),
('28', 'Semarang', '100.000'),
('27', 'Salatiga', '250.000'),
('19', 'Semarang', '250.000'),
('20', 'Semarang', '250.000'),
('21', 'Semarang', '250.000'),
('22', 'Semarang', '250.000'),
('23', 'Semarang', '250.000'),
('24', 'Semarang', '250.000'),
('25', 'Semarang', '250.000'),
('26', 'Tangerang', '200.000'),
('2', 'Salatiga', '200.000');
